git init
git add .
git commit -m "SwiftStay frontend init"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main