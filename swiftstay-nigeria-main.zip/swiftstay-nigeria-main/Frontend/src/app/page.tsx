export default function HomePage() {
      return (
          <section className="flex flex-col items-center justify-center text-center py-20">
                <h1 className="text-4xl font-bold text-blue-600">Welcome to SwiftStay Nigeria</h1>
                      <p className="mt-4 text-lg">Book hotels & apartments seamlessly across Nigeria.</p>
                          </section>
                            );
                            }
}