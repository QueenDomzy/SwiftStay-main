export interface AIResponse {
      reply: string;
      }
}